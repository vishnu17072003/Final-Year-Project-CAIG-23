from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')  # landing page

@app.route('/analyze')
def analyze():
    return render_template('analyze.html')  # this should be your interactive tool

# Optional: Add POST route to handle input if needed

if __name__ == '__main__':
    app.run(debug=True)
